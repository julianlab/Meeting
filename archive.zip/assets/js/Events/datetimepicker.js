$(document).ready(function() {
  $('#datetimepicker').datetimepicker({
    format: 'L',
    format: 'DD-MM-YYYY'
  });
});