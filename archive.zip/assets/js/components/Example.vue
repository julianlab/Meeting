<template>
    <div class="col-md-3 col-sm-1 col-1 text-center social-panel">
        <p>Here will be the new aside</p>
    </div>
</template>

<script>
    export default {
        name: "example"
    }
</script>

<style scoped>

</style>